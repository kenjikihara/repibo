$('.grid').masonry({
  columnWidth: 200,
  itemSelector: '.grid-item'
});
